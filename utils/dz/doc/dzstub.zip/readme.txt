This is the 16-bit STUB used in DZ.EXE

For a DOS-only distribution this may be used instead
This also applie to Windows vesions < XP (W95 - W98)

