Doszip Console Font

To install the font copy (use Windows) the dzcon.ttf file
to %SystemRoot%\fonts, or use the installer in the Control Panel

In addition to this the font must also be added to the Registry
You may do this manually or use the dzcon.reg file in WinXP

For more information about this:

http://support.microsoft.com/kb/247815

http://blogs.msdn.com/b/oldnewthing/archive/2007/05/16/2659903.aspx
